from django.urls import path
from .views import *

urlpatterns = [
    path('', index, name='index'),
    path('login/', login , name='login'),
    path('gestion/', gestion, name='gestion'),
    path('autor/', agregar_autor, name='autor'),
    path('contacto/', contacto, name='contacto'),
    path('modificar/<id_obra>/', modificar_obra, name='modificar'),
    path('eliminar/<id_obra>/', eliminar_obra, name='eliminar'),
    path('detalle/<id_obra>/', detalle, name='detalle'),
    path('register/', register, name='register'), 
]
